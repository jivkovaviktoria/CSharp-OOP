﻿namespace Easter.Core.Contracts
{
    using System;

    public interface IEngine
    {
        void Run();
    }
}