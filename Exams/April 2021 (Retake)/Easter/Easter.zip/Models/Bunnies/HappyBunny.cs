﻿namespace Easter.Models.Bunnies
{
    public class HappyBunny : Bunny
    {
        public HappyBunny(string name) : base(name, 100)
        {
        }
    }
}