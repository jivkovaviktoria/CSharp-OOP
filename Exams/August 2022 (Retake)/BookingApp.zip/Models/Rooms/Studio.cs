﻿namespace BookingApp.Models.Rooms
{
    public class Studio : Room
    {
        public Studio() : base(4)
        {
        }
    }
}