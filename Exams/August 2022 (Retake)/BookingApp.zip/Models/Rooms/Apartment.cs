﻿namespace BookingApp.Models.Rooms
{
    public class Apartment : Room
    {
        public Apartment() : base(6)
        {
        }
    }
}