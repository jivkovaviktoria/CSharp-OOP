﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Restaurant.Beverages.HotBeverages
{
    public class Tea : HotBeverage
    {
        public Tea(string name, decimal price, double millileters) : base(name, price, millileters)
        {

        }
    }
}
