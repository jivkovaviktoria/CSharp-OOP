﻿namespace MilitaryElite.Models.Contracts
{
    public interface IPrivate
    {
        public decimal Salary { get; set; }
    }
}