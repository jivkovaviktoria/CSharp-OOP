﻿namespace MilitaryElite.Models.Contracts
{
    public interface ISpecialisedSoldier
    {
        public string Corps { get; set; }
    }
}