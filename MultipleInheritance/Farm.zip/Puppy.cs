﻿namespace Farm
{
    using System;

    class Puppy : Dog
    {
        public void Weep() => Console.WriteLine("weeping...");
    }
}